# Color-Detector
The world is full of colors, and there are various colors that seem to be similar but they aren’t. In order to differentiate between the colors we require knowledge about them which is not possible for everyone to have. Especially for people who have color blindness.

So, in order to help them we came up with this project named color detector.When clicking on an image it gives its color of it in text format
